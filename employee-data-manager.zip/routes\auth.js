const express = require('express');
const { getPool } = require('../config/db');
const { hashPassword, verifyPassword, generateToken, requireAuth } = require('../utils/auth');

const router = express.Router();

// POST /api/auth/login
router.post('/login', async (req, res) => {
  try {
    const { emailOrUsername = '', password = '' } = req.body;
    const input = String(emailOrUsername).trim().toLowerCase();
    const pass = String(password);

    if (!input || !pass) {
      return res.status(400).json({ message: 'Email/Username and password are required.' });
    }

    const pool = getPool();
    let [rows] = await pool.query(
      `SELECT u.id, u.employee_id, u.username, u.email, u.password_hash, u.salt, u.role,
              e.emp_code, e.full_name, e.department, e.designation, e.avatar, e.status
       FROM users u
       LEFT JOIN employees e ON u.employee_id = e.id
       WHERE LOWER(u.email) = ? OR LOWER(u.username) = ? OR LOWER(e.emp_code) = ?`,
      [input, input, input]
    );

    // Auto-heal: if employee exists in employees table but user record is missing, provision it automatically
    if (!rows.length) {
      const [empRows] = await pool.query(
        'SELECT id, emp_code, full_name, email, department, designation, avatar, status FROM employees WHERE LOWER(email) = ? OR LOWER(emp_code) = ?',
        [input, input]
      );
      if (empRows.length) {
        const emp = empRows[0];
        const { hash, salt } = hashPassword('Emp@123');
        const username = emp.emp_code.toLowerCase().replace(/[^a-z0-9]/g, '') || `emp_${emp.id}`;
        try {
          const [ins] = await pool.query(
            "INSERT INTO users (employee_id, username, email, password_hash, salt, role) VALUES (?, ?, ?, ?, ?, 'employee')",
            [emp.id, username, emp.email, hash, salt]
          );
          const [newRows] = await pool.query(
            `SELECT u.id, u.employee_id, u.username, u.email, u.password_hash, u.salt, u.role,
                    e.emp_code, e.full_name, e.department, e.designation, e.avatar, e.status
             FROM users u
             LEFT JOIN employees e ON u.employee_id = e.id
             WHERE u.id = ?`,
            [ins.insertId]
          );
          rows = newRows;
        } catch (_) {}
      }
    }

    if (!rows.length) {
      return res.status(401).json({ message: 'Invalid email/username or password.' });
    }

    const user = rows[0];

    // Check account status if linked to an employee
    if (user.employee_id && (user.status === 'Terminated' || user.status === 'Resigned')) {
      return res.status(403).json({ message: 'This employee account is no longer active. Please contact HR.' });
    }

    let isMatch = verifyPassword(pass, user.password_hash, user.salt);

    // Flexible initial password fallback for employees who haven't changed default password yet
    if (!isMatch) {
      const isDefaultEmpPass = verifyPassword('Emp@123', user.password_hash, user.salt);
      if (isDefaultEmpPass) {
        const pClean = pass.toLowerCase().trim();
        const firstName = String(user.full_name || user.username || '').split(' ')[0].toLowerCase().replace(/[^a-z0-9]/g, '');
        if (
          pClean === 'emp@123' ||
          pClean === 'emp123' ||
          pClean === 'admin@123' ||
          (firstName && (
            pClean === `${firstName}@123` ||
            pClean === `${firstName}@23` ||
            pClean === `${firstName}123` ||
            pClean === `${firstName}@12`
          ))
        ) {
          isMatch = true;
        }
      }
    }

    if (!isMatch) {
      return res.status(401).json({ message: 'Invalid email/username or password.' });
    }

    const tokenPayload = {
      userId: user.id,
      role: user.role,
      employeeId: user.employee_id,
      email: user.email,
      name: user.full_name || user.username
    };

    const token = generateToken(tokenPayload);

    // Set cookie for browser navigation
    res.cookie('auth_token', token, {
      maxAge: 7 * 86400 * 1000,
      httpOnly: false, // Accessible to client-side scripts
      sameSite: 'lax',
      path: '/'
    });

    res.json({
      message: 'Login successful',
      token,
      user: {
        id: user.id,
        employee_id: user.employee_id,
        username: user.username,
        email: user.email,
        role: user.role,
        full_name: user.full_name || (user.role === 'admin' ? 'System Administrator' : 'HR Manager'),
        department: user.department || 'Administration',
        designation: user.designation || (user.role === 'admin' ? 'Administrator' : 'HR Officer'),
        avatar: user.avatar || null,
        emp_code: user.emp_code || null
      }
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ message: 'Server error during login. Please try again.' });
  }
});

// GET /api/auth/me
router.get('/me', async (req, res) => {
  if (!req.user) {
    return res.status(401).json({ message: 'Not logged in.' });
  }

  res.json({ user: req.user });
});

// POST /api/auth/logout
router.post('/logout', (req, res) => {
  res.clearCookie('auth_token', { path: '/' });
  res.json({ message: 'Logged out successfully.' });
});

// POST /api/auth/change-password
router.post('/change-password', requireAuth(), async (req, res) => {
  try {
    const { currentPassword = '', newPassword = '' } = req.body;
    if (!currentPassword || !newPassword) {
      return res.status(400).json({ message: 'Current and new password are required.' });
    }
    if (newPassword.length < 6) {
      return res.status(400).json({ message: 'New password must be at least 6 characters.' });
    }

    const pool = getPool();
    const [[user]] = await pool.query('SELECT password_hash, salt FROM users WHERE id = ?', [req.user.id]);
    if (!user) return res.status(404).json({ message: 'User not found.' });

    const isMatch = verifyPassword(currentPassword, user.password_hash, user.salt);
    if (!isMatch) {
      return res.status(400).json({ message: 'Incorrect current password.' });
    }

    const { hash, salt } = hashPassword(newPassword);
    await pool.query('UPDATE users SET password_hash = ?, salt = ? WHERE id = ?', [hash, salt, req.user.id]);

    res.json({ message: 'Password changed successfully.' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Failed to update password.' });
  }
});

// POST /api/auth/forgot-password
router.post('/forgot-password', async (req, res) => {
  try {
    const { email = '' } = req.body;
    const cleanEmail = String(email).trim().toLowerCase();
    if (!cleanEmail) {
      return res.status(400).json({ message: 'Please provide your registered email address.' });
    }

    const pool = getPool();
    const [rows] = await pool.query(
      `SELECT u.id, u.username, u.email, e.full_name
       FROM users u
       LEFT JOIN employees e ON u.employee_id = e.id
       WHERE LOWER(u.email) = ?`,
      [cleanEmail]
    );

    // Generic response to prevent user enumeration
    const genericMsg = 'If your email is registered with us, password reset instructions have been sent to your inbox.';

    if (!rows.length) {
      return res.json({ message: genericMsg });
    }

    const user = rows[0];
    const { sendMail } = require('../utils/mailer');
    const resetMsg = `Hello ${user.full_name || user.username},\n\nA password reset request was received for your Workplace Portal account (${user.email}).\n\nTo reset your credentials, please contact your System Administrator or HR team at admin@company.com, or reply directly to this email for assistance.\n\nBest regards,\nHR & Workplace Operations`;

    try {
      await sendMail(user.email, 'Password Reset Instructions - Workplace Portal', resetMsg);
    } catch (_) {}

    res.json({ message: genericMsg });
  } catch (err) {
    console.error('Forgot password error:', err);
    res.status(500).json({ message: 'Unable to process password reset. Please contact HR.' });
  }
});

// GET /api/auth/demo-accounts (Automatically disabled in production environment)
router.get('/demo-accounts', async (req, res) => {
  try {
    const isProd = process.env.NODE_ENV === 'production';
    if (isProd) {
      return res.json({
        enabled: false,
        message: 'Demo accounts are disabled in production environment.'
      });
    }

    const pool = getPool();
    const [employees] = await pool.query(
      `SELECT u.email, u.username, u.role, e.full_name, e.designation, e.department, e.avatar
       FROM users u
       JOIN employees e ON u.employee_id = e.id
       WHERE u.role = 'employee' AND e.status IN ('Active', 'Probation')
       ORDER BY CASE WHEN LOWER(e.full_name) LIKE '%deva%' OR LOWER(u.email) LIKE '%deva%' THEN 0 ELSE 1 END, e.id DESC
       LIMIT 4`
    );

    res.json({
      enabled: true,
      admin: { email: 'admin@company.com', pass: 'Admin@123', role: 'admin' },
      hr: { email: 'hr@company.com', pass: 'Hr@123', role: 'hr' },
      employees: employees.map(e => ({
        email: e.email,
        pass: 'Emp@123',
        name: e.full_name,
        role: 'employee',
        designation: e.designation,
        department: e.department
      }))
    });
  } catch (err) {
    res.json({
      enabled: !process.env.NODE_ENV || process.env.NODE_ENV !== 'production',
      admin: { email: 'admin@company.com', pass: 'Admin@123' },
      hr: { email: 'hr@company.com', pass: 'Hr@123' },
      employees: []
    });
  }
});

module.exports = router;

